package org.bouncycastle.tls;

/**
 * Marker interface to distinguish a TLS client context.
 */
public interface TlsClientContext
    extends TlsContext
{
}
