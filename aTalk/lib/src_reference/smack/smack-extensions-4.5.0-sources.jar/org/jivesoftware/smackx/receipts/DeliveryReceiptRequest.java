/*
 *
 * Copyright 2013-2014 the original author or authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jivesoftware.smackx.receipts;

import java.io.IOException;

import javax.xml.namespace.QName;

import org.jivesoftware.smack.packet.ExtensionElement;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.MessageBuilder;
import org.jivesoftware.smack.packet.Stanza;
import org.jivesoftware.smack.packet.XmlEnvironment;
import org.jivesoftware.smack.provider.ExtensionElementProvider;
import org.jivesoftware.smack.xml.XmlPullParser;
import org.jivesoftware.smack.xml.XmlPullParserException;

import org.jxmpp.JxmppContext;

/**
 * Represents a <b>message delivery receipt request</b> entry as specified by
 * <a href="http://xmpp.org/extensions/xep-0184.html">Message Delivery Receipts</a>.
 *
 * @author Georg Lukas
 */
public class DeliveryReceiptRequest implements ExtensionElement {
    public static final String ELEMENT = "request";
    public static final String NAMESPACE = DeliveryReceipt.NAMESPACE;
    public static final QName QNAME = new QName(NAMESPACE, ELEMENT);

    @Override
    public String getElementName() {
        return ELEMENT;
    }

    @Override
    public String getNamespace() {
        return DeliveryReceipt.NAMESPACE;
    }

    @Override
    public String toXML(org.jivesoftware.smack.packet.XmlEnvironment enclosingNamespace) {
        return "<request xmlns='" + DeliveryReceipt.NAMESPACE + "'/>";
    }

    /**
     * Get the {@link DeliveryReceiptRequest} extension of the packet, if any.
     *
     * @param p the packet
     * @return the {@link DeliveryReceiptRequest} extension or {@code null}
     * @deprecated use {@link #from(Stanza)} instead
     */
    @Deprecated
    public static DeliveryReceiptRequest getFrom(Stanza p) {
        return from(p);
    }

    /**
     * Get the {@link DeliveryReceiptRequest} extension of the packet, if any.
     *
     * @param packet the packet
     * @return the {@link DeliveryReceiptRequest} extension or {@code null}
     */
    public static DeliveryReceiptRequest from(Stanza packet) {
        return packet.getExtension(DeliveryReceiptRequest.class);
    }

    /**
     * Add a delivery receipt request to an outgoing packet.
     *
     * Only message packets may contain receipt requests as of XEP-0184,
     * therefore only allow Message as the parameter type.
     *
     * @param message Message object to add a request to
     * @return the Message ID which will be used as receipt ID
     */
    // TODO: Deprecate in favor of addTo(MessageBuilder) once connection's stanza interceptors use StanzaBuilder.
    public static String addTo(Message message) {
        message.throwIfNoStanzaId();

        message.addExtension(new DeliveryReceiptRequest());
        return message.getStanzaId();
    }

    /**
     * Add a delivery receipt request to an outgoing packet.
     *
     * Only message packets may contain receipt requests as of XEP-0184,
     * therefore only allow Message as the parameter type.
     *
     * @param messageBuilder Message object to add a request to
     */
    public static void addTo(MessageBuilder messageBuilder) {
        messageBuilder.throwIfNoStanzaId();

        messageBuilder.overrideExtension(new DeliveryReceiptRequest());
    }

    /**
     * This Provider parses and returns DeliveryReceiptRequest packets.
     */
    public static class Provider extends ExtensionElementProvider<DeliveryReceiptRequest> {
        @Override
        public DeliveryReceiptRequest parse(XmlPullParser parser,
                        int initialDepth, XmlEnvironment xmlEnvironment, JxmppContext jxmppContext) throws XmlPullParserException,
                        IOException {
            return new DeliveryReceiptRequest();
        }
    }
}
