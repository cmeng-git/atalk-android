java -cp "../fmj/build/classes.eclipse:classes" demo.Receiver &
#sleep 2
#java -cp "../fmj/build/classes.eclipse:classes" demo.Transmitter
