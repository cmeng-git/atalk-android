java -cp "lib/jmf.jar:classes" demo.Receiver &
#sleep 2
#java -cp "lib/jmf.jar:classes" demo.Transmitter
