#!/bin/sh
# Just runs the single session ZRTP transmitter application.
#
java -cp "../lib/jmf.jar:../lib/bcprov-jdk15on-148.jar:../lib/bccontrib-1.0-SNAPSHOT.jar:../classes" demo.TransmitterZRTP
